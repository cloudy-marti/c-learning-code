#ifndef EXO2__H
#define EXO2__H

int* fill_array(void);
int* random_array(int size, int max_entry);
int* concat_array(int* first, int* second);

#endif