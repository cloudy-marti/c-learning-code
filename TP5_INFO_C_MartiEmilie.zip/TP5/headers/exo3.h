#ifndef EXO3__H
#define EXO3__H

int* merge_sorted_arrays(int* first, int* second);
void split_arrays(int* array, int** first, int** second);
int* merge_sort(int* array);

#endif