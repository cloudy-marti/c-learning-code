#ifndef EXO0__H
#define EXO0__H

int* allocate_integer_array(int size);
void free_integer_array(int* tab);
void bubbleSort(int* tab, int size);

#endif