#ifndef EXO1__H
#define EXO1__H

int array_size(int* array);
void print_array(int* array);
int are_arrays_equal(int* first, int* second);
int* copy_array(int* array);

#endif