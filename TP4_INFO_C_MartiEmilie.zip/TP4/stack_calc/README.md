Calculatrice : Lit les nombres en POSTFIXE

1 + 1 = 2
1 1 + = 2

1 + (3 x 2) == 1 3 2 x +