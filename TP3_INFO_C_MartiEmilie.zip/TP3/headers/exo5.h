#ifndef EXO5__H
#define EXO5__H

void bubbleSort(int* tab, int size);

#endif