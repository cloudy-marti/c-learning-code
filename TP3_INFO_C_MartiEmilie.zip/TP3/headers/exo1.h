#ifndef EXO1__H
#define EXO1__H

int power(int a, int n);
int recPower(int a, int n);
int recOptiPower(int a, int n);

#endif