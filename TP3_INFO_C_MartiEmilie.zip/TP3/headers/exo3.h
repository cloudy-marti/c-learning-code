#ifndef EXO3__H
#define EXO3__H

int checkstring(char* string);
void to10(char* string);
void to26(char* string);
void mirror(char* string);
void conversion(char* string);

#endif
