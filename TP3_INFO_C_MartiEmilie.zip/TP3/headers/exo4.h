#ifndef EXO4__H
#define EXO4__H

int binarySearch(int* tab, int min, int max, int nb);
void printArray(int* string, int size);
void fillRandArray(int* string, int size);

#endif
