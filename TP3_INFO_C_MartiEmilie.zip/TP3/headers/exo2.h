#ifndef EXO2__H
#define EXO2__H

void wCount(char* string);

#endif